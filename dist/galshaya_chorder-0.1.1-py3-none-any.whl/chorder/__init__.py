"""
Chorder - A command-line tool for formatting and transposing chord charts
"""

__version__ = "0.1.1" 